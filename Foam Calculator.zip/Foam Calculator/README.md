# PU Foam + STL Fill Visualizer

Upload an STL, visualize the model, and animate a rising fill level to simulate foam injection while sizing your pour from mold volume and expansion; includes an SOP helper and Groq-powered explainer.

## Run

pip install -r requirements.txt
streamlit run app.py
